import React from 'react'
import './Signup.css';
function Signup() {
  return (
    <>
       <div className="background">
      <div className="logintitle p-4 text-info d-flex align-items-center justify-content-center">
        <h2>Make the most of Professional life</h2>
      </div>
      <form className=" w-50 mx-auto bg-light my-3 p-4">
        <div className="mx-5 p-2">
          <label for="exampleInputName" className="form-label">
            Name
          </label>
          <div class="col-8">
            <input type="text" className="form-control" id="exampleInputName" />
          </div>
        </div>
        <div className="mx-5 p-2">
          <label for="exampleInputEmail1" className="form-label">
            Email address
          </label>
          <div class="col-8">
            <input
              type="email"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
            />
          </div>
          
        </div>
        <div className="mx-5 p-2">
          <label for="exampleInputPassword1" className="form-label">
            Password
          </label>
          <div class="col-8">
            <input
              type="password"
              className="form-control wd-50"
              id="exampleInputPassword1"
            />
          </div>
        </div>
        <div className="mx-5 p-2">
          <label for="exampleInputPassword2" className="form-label">
           Confirm Password
          </label>
          <div class="col-8">
            <input
              type="password"
              className="form-control wd-50"
              id="exampleInputPassword2"
            />
          </div>
        </div>
        <div className='submit-btn'>
        <button type="submit" className=" btn btn-primary m-5">
          Submit
        </button>
        </div>
      </form>
      </div>
    </>
  )
}

export default Signup
