import React from 'react'
import './Login.css'
function Login() {
  return (
    <div>
        <div className="login_background ">
      <form className=" w-50 mx-auto my-auto  p-4 bg-light">
        <div className="Logintitle mx-5  px-2 py-3">
            <h1>Login</h1>
        </div>
        <div className="mx-5 p-2">
          <label for="exampleInputEmail1" className="form-label">
            Email address
          </label>
          <div class="col-8">
            <input
              type="email"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
            />
          </div>
          
        </div>
        <div className="mx-5 p-2">
          <label for="exampleInputPassword1" className="form-label">
            Password
          </label>
          <div class="col-8">
            <input
              type="password"
              className="form-control wd-50"
              id="exampleInputPassword1"
            />
          </div>
        </div>
        <div className='submit-btn'>
        <button type="submit" className=" btn btn-primary m-5">
          Submit
        </button>
        </div>
      </form>
      </div>
    </div>
  )
}

export default Login
