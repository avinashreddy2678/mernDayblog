import React, { useEffect, useState } from 'react'
import Modal from "@mui/material/Modal"
import './modalops.css'

function Modalops({open ,handleclose,handlecancel,handlePostData}) {
    let name='Avinash';
    let [postText,setpostText]=useState([{
        title:'',
        post:''
    }]);
    let [finalpost,setfinalpost]=useState([]);
    const handlechange = (e) => {
        const { name, value } = e.target;
        setpostText((prevPostText) => ({
          ...prevPostText,
          [name]: value
        }));
      }
    const handlePost=()=>{
        postText=[...finalpost,postText]
        setfinalpost(postText);
        setpostText("");
        handleclose();
    }
    useEffect(()=>handlePostData(finalpost),[finalpost]); 
  return (   
   <>
    <Modal
        open={open}
        onClose={handleclose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
    
    <div className='modals'>
        <div className="modalcontent">
                  <div className="navb">
                        <div className="left">
                                    
                                <div className="name">
                                            <h4>{name}</h4>
                                            <p className='para'>Post to Everyone</p>
                                </div>
                        </div>
                        <div className="right">
                                <button onClick={handlecancel}>
                                    close
                                </button>
                        </div>
                  </div>
                  <div className="Maincontainer">
                    <input type="text" placeholder='title' name='title' value={postText.title} onChange={handlechange} />
                        <textarea type="text" rows={20} placeholder='What do you want to talk about ?' name='post' value={postText.post} onChange={handlechange}/>
                  </div>

                  <div className="bottom">
                            
                            <div className="bottomright">
                                
                            <button variant="contained" onClick={handlePost}>
                                     Post
                                 </button>
                   
                            </div>
                            
                                   
                  </div>
        </div>
       
    </div>
    </Modal>
    </>
  )
}

export default Modalops
