import React from 'react'

function Post({item,name}) {
  return (
    <>
      <h1>{item.title}</h1>
      <p>{item.post}</p>
      <h6 style={{float:"right",marginRight:"10%"}}>-{name}</h6>
    </>
  )
}

export default Post
