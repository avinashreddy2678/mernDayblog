import React, { useState } from "react";
import "./Home.css";
import data from "../data/Mypostsdata";
import Post from "./Post";
import Modalops from './Modalops'
function Home() {
    let name='avinash'
    const [mydata,setdata]=useState([...data]);
    const [open,setopen]=useState(false);
    const hanldeonclick=()=>{
            setopen(true);
    }
    const handleclose=()=>{
        setopen(false)
    }
    const handlecancel=()=>{
        setopen(false)
    }
    const handlepost=(postArray)=>{
        setdata([...data,...postArray])
    }
  return (
    <div className="Homepage-container">
      <nav class="navbar navbar-expand-lg bg-body-tertiary px-5">
        <div class="container-fluid">
          <a class="navbar-brand" href="/">
            Daily-Journels
          </a>
          
          <div>
            <ul class="navbar-nav">
              <li class="nav-item px-5">
                <a class="nav-link active" aria-current="page" href="/">
                 <b>Myposts</b> 
                </a>
              </li>
              <li class="nav-item px-5">
                <a class="nav-link" href="/">
                <b>Profile</b>  
                </a>
              </li>
              <li class="nav-item px-5">
                <a class="nav-link" href="/">
                <b>Pricing</b>  
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div className="input-box">
      <div className="inputbox">
                <input 
                type="none"
                placeholder='Start a Post'
                value=''
                onClick={hanldeonclick}
                />
            </div>
            <Modalops 
         open={open}
         handleclose={handleclose}
         handlecancel={handlecancel}
         handlePostData={handlepost}
         />
      </div>
      <div className="posts">

        {mydata.map((item) => (
            <div className="singlepost">
        <Post key={item.id} item={item} name={name}/>
        </div>
      ))}
      </div>
      
    </div>
  );
}

export default Home;
