
import './App.css';
import Home from './Homecomponents/Home';
import Log from './Log';
import "bootstrap/dist/css/bootstrap.min.css";
function App() {
  return (
    <>
  
    <Log/> 
     <Home/>
    </>
  );
}

export default App;
