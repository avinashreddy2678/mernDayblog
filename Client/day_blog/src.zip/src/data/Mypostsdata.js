const data = [
  {
    title: "Day-1",
    post: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias aspernatur quo ullam quas iste voluptates quis quia dolore magni asperiores odit expedita eos consequuntur consectetur, neque nostrum quae tempore laborum? ",
  },
  {
    title: "Day-2",
    post: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias aspernatur quo ullam quas iste voluptates quis quia dolore magni asperiores odit expedita eos consequuntur consectetur, neque nostrum quae tempore laborum? ",
  },
  
  {
    title: "Day-3",
    post: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias aspernatur quo ullam quas iste voluptates quis quia dolore magni asperiores odit expedita eos consequuntur consectetur, neque nostrum quae tempore laborum? ",
  }
];
export default data;
