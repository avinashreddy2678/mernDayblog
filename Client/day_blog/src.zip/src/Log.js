import React from 'react'
import Login from './LogComponents/Login'
import Signup from './LogComponents/Signup'
import LogSign from './LogComponents/LogSign'
import { Routes,Route } from 'react-router-dom'
function Log() {
  return (
    <div>
        <Routes>
            <Route path='/' element={<LogSign/>}></Route>
            <Route path='/signup' element={<Signup/>}/>
            <Route path='/login' element={<Login/>}/>
        </Routes>
    </div>
  )
}

export default Log
